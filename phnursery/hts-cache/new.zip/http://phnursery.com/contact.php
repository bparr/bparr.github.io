<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" type="text/css" href="style.css" />
		<script type="text/javascript" src="phnursery.js"></script>		<title>Contact - P &amp; H Nursery: Growers Specializing in Boxwoods (Buxus)</title>	</head>
	<body>
		<div id="page-wrapper">
			<div id="header">
				<h1>P &amp; H Nursery</h1>
				<h4>Growers Specializing in Boxwoods (Buxus)</h4><hr />
			</div>
			<div id="content">


<h2>Contact Us</h2>
<p id="contact-instructions">You can contact us by filling out the form below.</p>

<br /><hr /><br />

<form method="post" action="contact2.php">
	<table class="form">
		<tr>
			<th colspan="2">Contact Us Form</th>
		</tr>

		<tr>
			<td><p class="req">Name:</p></td>
			<td><input type="text" name="name" size="20" /></td>
		</tr>
	  
		<tr>
			<td><p class="req"> Email:</p></td>
			<td><input type="text" name="email" size="20" /></td>
		</tr>

		<tr>
			<td><p class="req"> Phone #:</p></td>
			<td><input type="text" name="phone" size="20" /></td>
		</tr>

		<tr>
			<td><b>Plant(s) of Interest:</b></td>
			<td><input type="text" name="plants" size="40" value="" /></td>
		</tr>

		<tr>
			<td><b>Message:</b></td>
			<td><textarea cols="40" rows="5" name="message"></textarea></td>
		</tr>

		<tr>
			<td colspan="2" align="center"><input type="submit" name="submit" value="Send" /></td>
		</tr>

	</table>
</form>

<p><b>Required fields: </b>Name, Email or Phone # (We need your email address and/or phone number in order to contact you.)</p>


			</div>
			<div id="navigation">
				<ul>
					<li><a href="/">Home</a></li>
					<li><a href="plantlist.php">Boxwoods</a>
						<ul>
							<li><a href="plantlist.php?type=1">Dwarf</a></li>
							<li><a href="plantlist.php?type=2">Medium</a></li>
							<li><a href="plantlist.php?type=3">Large</a></li>
							<li><a href="plantlist.php?type=4">Upright</a></li>
						</ul>
					</li>
					<li><a href="otherplants.php">Shrubs &amp; Perennials</a></li>
					<li><a href="gardenclub.php">Garden Club Tours</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</body>
</html>

