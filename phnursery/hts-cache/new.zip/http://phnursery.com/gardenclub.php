<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" type="text/css" href="style.css" />
		<title>Garden Club Tours - P &amp; H Nursery: Growers Specializing in Boxwoods (Buxus)</title>	</head>
	<body>
		<div id="page-wrapper">
			<div id="header">
				<h1>P &amp; H Nursery</h1>
				<h4>Growers Specializing in Boxwoods (Buxus)</h4><hr />
			</div>
			<div id="content">


<h2>Garden Club Tours Welcome</h2>
<a href="photos/gardenclub/1.jpeg"><img src="photos/gardenclub/preview1.jpeg" alt="Garden Club Photo" /></a>
<p>Come tour our beautifully landscaped multi-acre home.  Visit our rose and perennial gardens along with our lovely water feature.</p>
<p>Speaking engagements upon requests. Pat Parr has spoken to numerous clubs and would be happy to speak at local garden clubs near Clifton, VA or on-site at P &amp; H Nursery.   Potential speaking topics include:</p>
<ul>
	<li>Shade gardening</li>
	<li>Rose gardening</li>
	<li>Deer proofing</li>
	<li>Adding water features to landscape design</li>
	<li>How to develop landscape plans</li>
</ul>
<br />
<p><a href="contact.php"><strong>Contact Us</strong></a></p>
<br />
<a href="photos/gardenclub/2.jpeg"><img src="photos/gardenclub/preview2.jpeg" width="220" height="180" alt="Garden Club Photo" /></a>
<a href="photos/gardenclub/3.jpeg"><img src="photos/gardenclub/preview3.jpeg" width="220" height="180" alt="Garden Club Photo" /></a>


			</div>
			<div id="navigation">
				<ul>
					<li><a href="/">Home</a></li>
					<li><a href="plantlist.php">Boxwoods</a>
						<ul>
							<li><a href="plantlist.php?type=1">Dwarf</a></li>
							<li><a href="plantlist.php?type=2">Medium</a></li>
							<li><a href="plantlist.php?type=3">Large</a></li>
							<li><a href="plantlist.php?type=4">Upright</a></li>
						</ul>
					</li>
					<li><a href="otherplants.php">Shrubs &amp; Perennials</a></li>
					<li><a href="gardenclub.php">Garden Club Tours</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</body>
</html>

