<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" type="text/css" href="style.css" />
		<title>Shrubs and Perennials - P &amp; H Nursery: Growers Specializing in Boxwoods (Buxus)</title>	</head>
	<body>
		<div id="page-wrapper">
			<div id="header">
				<h1>P &amp; H Nursery</h1>
				<h4>Growers Specializing in Boxwoods (Buxus)</h4><hr />
			</div>
			<div id="content">


<h2>Shrubs and Perennials</h2>
<a href="photos/otherplants/1.jpeg"><img src="photos/otherplants/preview1.jpeg" width="220" height="180" alt="Shrubs and Perennials Photo" /></a>
<a href="photos/otherplants/2.jpeg"><img src="photos/otherplants/preview2.jpeg" width="220" height="180" alt="Shrubs and Perennials Photo" /></a>
<p>P &amp; H Nursery grows both shrubs and perennials.  Numerous types of shrubs and perennials are available in limited quantity.</p>
<table class="otherplants">
	<tr>
		<th>Shrubs</th>
		<th>Perennials</th>
	</tr>
	<tr>
		<td class="first-column">
			<ul>
				<li>Abelia</li>
				<li>Azaleas</li>
				<li>Aucuba</li>
				<li>Barberry</li>
				<li>Holly</li>
				<li>Hydrangea</li>
				<li>Juniper</li>
				<li>Leyland Cypruss</li>
				<li>Mahonia</li>
				<li>Maple Dissectum</li>
				<li>Nandina</li>
				<li>Spirea</li>
				<li>Viburnum</li>
			</ul>
		</td>

		<td>
			<ul>
				<li>Astilbe</li>
				<li>Coreopsis</li>
				<li>Day Lily</li>
				<li>Dianthus</li>
				<li>Echinacea</li>
				<li>Fern</li>
				<li>Geranuim (Hardy)</li>
				<li>Grasses</li>
				<li>Helleborus</li>
				<li>Iberis</li>
				<li>Liriope</li>
				<li>Mondo Grass</li>
				<li>Nepeta (Cat Mint)</li>
				<li>Phlox Divaricata</li>
				<li>Tiarella</li>
			</ul>
		</td>
	</tr>
</table>
<br />
<p><a href="contact.php"><strong>Contact Us</strong></a></p>
<br />
<a href="photos/otherplants/3.jpeg"><img src="photos/otherplants/preview3.jpeg" width="220" height="180" alt="Shrubs and Perennials Photo" /></a>
<a href="photos/otherplants/4.jpeg"><img src="photos/otherplants/preview4.jpeg" width="220" height="180" alt="Shrubs and Perennials Photo" /></a>


			</div>
			<div id="navigation">
				<ul>
					<li><a href="/">Home</a></li>
					<li><a href="plantlist.php">Boxwoods</a>
						<ul>
							<li><a href="plantlist.php?type=1">Dwarf</a></li>
							<li><a href="plantlist.php?type=2">Medium</a></li>
							<li><a href="plantlist.php?type=3">Large</a></li>
							<li><a href="plantlist.php?type=4">Upright</a></li>
						</ul>
					</li>
					<li><a href="otherplants.php">Shrubs &amp; Perennials</a></li>
					<li><a href="gardenclub.php">Garden Club Tours</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</body>
</html>

