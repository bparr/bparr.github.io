<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" type="text/css" href="style.css" />
		<title>All Boxwoods - P &amp; H Nursery: Growers Specializing in Boxwoods (Buxus)</title>	</head>
	<body>
		<div id="page-wrapper">
			<div id="header">
				<h1>P &amp; H Nursery</h1>
				<h4>Growers Specializing in Boxwoods (Buxus)</h4><hr />
			</div>
			<div id="content">

<h2>Plant List: All Boxwoods</h2>
<table class="plant-list">
	<tr><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=12">
						<img src="photos/boxwoods/preview19.jpeg" width="115" height="87" alt="American Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=12">
							American Boxwood<br /><br />Sempervirens
					</a>
				</td>
			</tr>
		</table>
	</td><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=3">
						<img src="photos/boxwoods/preview5.jpeg" width="115" height="151" alt="Dee Runk Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=3">
							Dee Runk Boxwood<br /><br />Sempervirens
					</a>
				</td>
			</tr>
		</table>
	</td></tr>
	<tr><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=13">
						<img src="photos/boxwoods/preview22.jpeg" width="115" height="151" alt="Elegantissima Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=13">
							Elegantissima Boxwood<br /><br />Sempervirens
					</a>
				</td>
			</tr>
		</table>
	</td><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=7">
						<img src="photos/boxwoods/preview10.jpeg" width="115" height="87" alt="English Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=7">
							English Boxwood<br /><br />Sempervires 'Suffruiticosa'
					</a>
				</td>
			</tr>
		</table>
	</td></tr>
	<tr><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=4">
						<img src="photos/boxwoods/preview7.jpeg" width="115" height="151" alt="Fastigiata Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=4">
							Fastigiata Boxwood<br /><br />Sempervirens
					</a>
				</td>
			</tr>
		</table>
	</td><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=1">
						<img src="photos/boxwoods/preview1.jpeg" width="115" height="151" alt="Grace Hendrick Phillips Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=1">
							Grace Hendrick Phillips Boxwood<br /><br />Microphylla
					</a>
				</td>
			</tr>
		</table>
	</td></tr>
	<tr><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=5">
						<img src="photos/boxwoods/preview8.jpeg" width="115" height="151" alt="Graham Blandy Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=5">
							Graham Blandy Boxwood<br /><br />Sempervirens
					</a>
				</td>
			</tr>
		</table>
	</td><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=10">
						<img src="photos/boxwoods/preview17.jpeg" width="115" height="151" alt="Green Mound Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=10">
							Green Mound Boxwood<br /><br />Sempervirens
					</a>
				</td>
			</tr>
		</table>
	</td></tr>
	<tr><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=11">
						<img src="photos/boxwoods/preview18.jpeg" width="115" height="151" alt="Green Mountain Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=11">
							Green Mountain Boxwood<br /><br />Sempervirens var. Insularis
					</a>
				</td>
			</tr>
		</table>
	</td><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=6">
						<img src="photos/boxwoods/preview9.jpeg" width="115" height="87" alt="Jensen Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=6">
							Jensen Boxwood<br /><br />Sempervirens
					</a>
				</td>
			</tr>
		</table>
	</td></tr>
	<tr><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=9">
						<img src="photos/boxwoods/preview16.jpeg" width="115" height="151" alt="Justin Brouwers Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=9">
							Justin Brouwers Boxwood<br /><br />Sinica var. Insularis
					</a>
				</td>
			</tr>
		</table>
	</td><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=2">
						<img src="photos/boxwoods/preview2.jpeg" width="115" height="153" alt="Morris Dwarf Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=2">
							Morris Dwarf Boxwood<br /><br />Microphylla var. japonica
					</a>
				</td>
			</tr>
		</table>
	</td></tr>
	<tr><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=8">
						<img src="photos/boxwoods/preview15.jpeg" width="115" height="151" alt="Vardar Valley Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=8">
							Vardar Valley Boxwood<br /><br />Sempervirens
					</a>
				</td>
			</tr>
		</table>
	</td><td>
		<table class="plant-list-item">
			<tr>
				<td>
					<a href="plant.php?plant=14">
						<img src="photos/boxwoods/preview23.jpeg" width="115" height="151" alt="Winter Gem Boxwood" />
					</a>
				</td>
				<td>
					<a href="plant.php?plant=14">
							Winter Gem Boxwood<br /><br />Microphylla var. Japonica
					</a>
				</td>
			</tr>
		</table>
	</td></tr>
</table>
			</div>
			<div id="navigation">
				<ul>
					<li><a href="/">Home</a></li>
					<li><a href="plantlist.php">Boxwoods</a>
						<ul>
							<li><a href="plantlist.php?type=1">Dwarf</a></li>
							<li><a href="plantlist.php?type=2">Medium</a></li>
							<li><a href="plantlist.php?type=3">Large</a></li>
							<li><a href="plantlist.php?type=4">Upright</a></li>
						</ul>
					</li>
					<li><a href="otherplants.php">Shrubs &amp; Perennials</a></li>
					<li><a href="gardenclub.php">Garden Club Tours</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</body>
</html>
